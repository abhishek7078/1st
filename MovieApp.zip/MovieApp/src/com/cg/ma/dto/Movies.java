package com.cg.ma.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class Movies {
	
	@Id
	@Column
	private int movieid;
	
	@Column
	private String moviename;
	
	@Column
	private int movieprice;
	
	@Column
	private String moviestar;
	
	public Movies(int movieid, String moviename, int movieprice,
			String moviestar) {
		super();
		this.movieid = movieid;
		this.moviename = moviename;
		this.movieprice = movieprice;
		this.moviestar = moviestar;
	}
	public Movies() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getMovieid() {
		return movieid;
	}
	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}
	public String getMoviename() {
		return moviename;
	}
	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}
	public int getMovieprice() {
		return movieprice;
	}
	public void setMovieprice(int movieprice) {
		this.movieprice = movieprice;
	}
	public String getMoviestar() {
		return moviestar;
	}
	public void setMoviestar(String moviestar) {
		this.moviestar = moviestar;
	}
	@Override
	public String toString() {
		return "Movies [movieid=" + movieid + ", moviename=" + moviename
				+ ", movieprice=" + movieprice + ", moviestar=" + moviestar
				+ "]";
	}
	
	
	
	
	

}

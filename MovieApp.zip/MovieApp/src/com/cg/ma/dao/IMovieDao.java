package com.cg.ma.dao;

import java.util.List;

import com.cg.ma.dto.Movies;


public interface IMovieDao {

	

	public List<Movies> getAllMovies();

	public Movies getMovieDetails(int movid);
	 
	public int updateMovies(Movies mov);

	public List<Movies> delete(int mov);

}

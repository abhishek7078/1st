package com.cg.ma.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ma.dto.Movies;



@Repository("dao")
public class MovieImpl implements IMovieDao {

	@PersistenceContext
	EntityManager entitymanager;


	@Override
	public List<Movies> getAllMovies() {

		String str="select movie from Movies movie";
		TypedQuery<Movies> queryOne=(TypedQuery<Movies>) entitymanager.createQuery(str,Movies.class);
		List<Movies> myList=queryOne.getResultList();
		return myList;

	}

	@Override
	public Movies getMovieDetails(int movid) {
		Movies movie = entitymanager.find(Movies.class, movid);
		System.out.println(movie);
		return movie;
	}

	@Override
	public int updateMovies(Movies mov) {
		entitymanager.merge(mov);
		return mov.getMovieid();

	}

	@Override
	public List<Movies> delete(int movid) {

		Movies movie = getMovieDetails(movid);
		entitymanager.remove(movie);
		return getAllMovies();
	}

}

package com.cg.ma.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.ma.dto.Movies;
import com.cg.ma.service.IMovieService;

@Controller
public class MovieController {
	
	@Autowired
	IMovieService service;
	
	@RequestMapping("getmovlist")
	public String showMobileList(Model model){
		List<Movies> list = service.getAllMovies();
		model.addAttribute("list",list);
		return "home";
	}
	

	@RequestMapping("getUpdatePage")
	public String sendUpdatePage(@RequestParam("movid") int movid,Model model)
	{
		System.out.println("nvifdrjhik");
		Movies movie = service.getMovieDetails(movid);
		if(movie ==null)
		{
			model.addAttribute("errormsg","Movie id is not valid");
			return "error";
		}
		else
		{	
			model.addAttribute("movie", movie);
			return "update";
		}
	}
	
	@RequestMapping("updateMobileAction")
	public String updatedPage(@ModelAttribute("movie") Movies mov ,Model model){
		service.updateMovies(mov);
		model.addAttribute("msg","Movie Data successfully updated");
		return "success";
		
	}
	
}

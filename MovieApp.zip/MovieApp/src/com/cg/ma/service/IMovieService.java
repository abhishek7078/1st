package com.cg.ma.service;

import java.util.List;

import com.cg.ma.dto.Movies;

public interface IMovieService {

	

	public List<Movies> getAllMovies();

	public Movies getMovieDetails(int movid);
	 
	public int updateMovies(Movies mov);

	public List<Movies> delete(int mov);

	
}

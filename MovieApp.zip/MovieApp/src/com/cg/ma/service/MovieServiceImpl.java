package com.cg.ma.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ma.dao.IMovieDao;
import com.cg.ma.dto.Movies;
import com.cg.ma.dao.IMovieDao;

@Service("service")
@Transactional
public class MovieServiceImpl implements IMovieService
{

	@Autowired
	IMovieDao dao;

	
	@Override
	public List<Movies> getAllMovies() {
		// TODO Auto-generated method stub
		return dao.getAllMovies();
	}

	@Override
	public Movies getMovieDetails(int movid) {
		// TODO Auto-generated method stub
		return dao.getMovieDetails(movid);
	}

	@Override
	public int updateMovies(Movies mov) {
		// TODO Auto-generated method stub
		return dao.updateMovies(mov);
	}

	@Override
	public List<Movies> delete(int mov) {
		// TODO Auto-generated method stub
		return dao.delete(mov);
	}
	
	
	
}


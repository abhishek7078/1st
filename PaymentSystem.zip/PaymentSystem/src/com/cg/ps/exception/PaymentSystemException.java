package com.cg.ps.exception;

public class PaymentSystemException extends Exception{
	public PaymentSystemException(String message){
		super(message);
	}
}

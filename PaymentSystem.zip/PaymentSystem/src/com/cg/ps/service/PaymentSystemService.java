package com.cg.ps.service;

import com.cg.ps.dto.Customer;
import com.cg.ps.exception.PaymentSystemException;

public interface PaymentSystemService {

	public void createAccount(Customer customer);
	
	public void deposit(String mobileNo, double amount);
	
	public void withdraw(String mobileNo, double amount);
	
	public double checkBalance(String mobileNo);
	
	public void fundTransfer(String sender, String reciever, double amount);
	
	
	public boolean validateAccount(String mobileNo) throws PaymentSystemException;
	
	public boolean validateName(String name) throws PaymentSystemException;
	
	public boolean validateAge(float age) throws PaymentSystemException;
	
	public boolean validateMoileNo(String mobileNo) throws PaymentSystemException;
	
	public boolean validateAmount(double amount) throws PaymentSystemException;
			
}

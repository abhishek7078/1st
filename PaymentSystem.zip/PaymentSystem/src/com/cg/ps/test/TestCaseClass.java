package com.cg.ps.test;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.cg.ps.exception.PaymentSystemException;
import com.cg.ps.service.PaymentSystemService;
import com.cg.ps.service.PaymentSystemServiceImpl;

public class TestCaseClass {

	@Test(expected=PaymentSystemException.class)
    public void test_ValidateName_null() throws PaymentSystemException{
		PaymentSystemService service=new PaymentSystemServiceImpl();
        service.validateName(null);
    }
    
    @Test
    public void test_validateName_v1() throws PaymentSystemtException{
    
        String name="Aete121";
        PaymentSystemService service=new PaymentSystemServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
    @Test
    public void test_validateName_v2() throws PaymentSystemException{
    
        String name="Amita";
        PaymentSystemService service=new PaymentSystemServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(true,result);
    }
    @Test
    public void test_validateName_v3() throws PaymentSystemtException{
    
        String name="amita";
        PaymentSystemService service=new PaymentSystemServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
    @Test(expected=PaymentSystemException.class)
    public void test_ValidateMobNo_null() throws PaymentSystemException{
    	PaymentSystemService service=new PaymentSystemServiceImpl();
        service.validateMoileNo(null);
    }
    
    @Test
    public void test_validateMobNo_v1() throws PaymentSystemException{
    
        String mobNo="ABCD91828288";
        PaymentSystemService service=new PaymentSystemServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(false,result);
    }
    @Test
    public void test_validateMobNo_v2() throws PaymentSystemException{
    
        String mobNo="9922974725";
        PaymentSystemService service=new PaymentSystemServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(true,result);
    }
    @Test
    public void test_validateMobNo_v3() throws PaymentSystemException{
    
        String mobNo="992297";
        PaymentSystemtService service=new PaymentSystemServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(false,result);
    }
	
}

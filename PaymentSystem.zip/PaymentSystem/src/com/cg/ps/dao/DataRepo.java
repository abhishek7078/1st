package com.cg.ps.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.ps.dto.Customer;

public class DataRepo {
	private static Map<String, Customer> customer;
	static Map<String, Customer> createCollection(){
		if(customer == null)
			customer = new HashMap<>();		
		return customer;		
	}

}

package com.cg.mobshop.service;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;

public interface IMobileService {
public List<Mobiles> getAllMobiles();	
	
	
	


	Mobiles getMobileDetails(int mobid);
	
}

package com.cg.mobshop.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.cg.mobshop.dao.IMobileDao;
import com.cg.mobshop.dto.Mobiles;

@Service
public class MobileServiceImpl implements IMobileService {

	@Autowired
	IMobileDao dao;
	
	public IMobileDao getDao(){
		return dao;
		
	}

	public void setDao(IMobileDao dao){
		this.dao=dao;
	}
	
	@Override
	public List<Mobiles> getAllMobiles()
	{
		return dao.getAllMobiles();
	}

	

	@Override
	public Mobiles getMobileDetails(int mobid) {
		// TODO Auto-generated method stub
		return dao.getMobileDetails(mobid);
	}
	
	
}

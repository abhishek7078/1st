package com.cg.mobshop.dao;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;


public interface IMobileDao {


	List<Mobiles> getAllMobiles();
	
	
	
	
	
}

package com.cg.psj.exception;

public class PsjException extends Exception{

	public PsjException(String message){
		super(message);

	}
}
